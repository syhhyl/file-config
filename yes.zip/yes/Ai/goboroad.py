for i in range(0, 32):
    n = f"{i:05b}"
    list(n)
    x = [int(j) for j in n]
    
    z, q, s, l, h = x
    
    if (not z or q) and (l or h) and ((q and not s) or (not q and s)) \
        and ((s and l) or (not s and not l)) \
        and (not h or (z and q)):
        print(f"方案{i} :")
        if z: print("赵")
        else: print("赵不去")
        if q: print("钱")
        else: print("钱不去")
        if s: print("孙")
        else: print("孙不去")
        if l: print("李")
        else: print("李不去")
        if h: print("周")
        else: print("周不去")
        



