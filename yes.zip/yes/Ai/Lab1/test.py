
s = "1 2 3"
new_s = s.split()
print(new_s)
print(list(map(int, new_s)))
#numbers = list(map(int, s))
