import sys

# 汽车特征库
features = [
    "",  # 占位符，使索引从1开始
    "四门", "两门", "敞篷", "后驱", "前驱", "四驱",
    "大空间", "高底盘", "运动外观", "流线型", "大马力",
    "豪华内饰", "商用", "载重", "电动", "混合动力",
    "汽油", "柴油", "自动挡", "手动挡", "7座以上"
]

# 汽车品牌特征
brands = {
    "轿车": {
        "丰田卡罗拉": [1, 5, 19, 17],
        "本田雅阁": [1, 5, 19, 17],
        "宝马3系": [1, 4, 19, 17],
        "奔驰C级": [1, 4, 19, 17, 12]
    },
    "SUV": {
        "丰田RAV4": [1, 6, 19, 17, 8],
        "本田CR-V": [1, 6, 19, 17, 8],
        "宝马X5": [2, 6, 19, 17, 12],
        "奔驰GLC": [1, 6, 19, 17, 12]
    },
    "跑车": {
        "保时捷911": [2, 4, 10, 11, 17],
        "法拉利488": [2, 4, 10, 11, 17],
        "兰博基尼Huracan": [2, 4, 3, 10, 11, 17]
    },
    "卡车": {
        "福特F-150": [1, 6, 14, 17, 20],
        "雪佛兰Silverado": [1, 6, 14, 17, 20],
        "奔驰Actros": [1, 6, 13, 14, 18]
    },
    "电动车": {
        "特斯拉Model S": [1, 4, 15, 19, 10],
        "特斯拉Model 3": [1, 5, 15, 19],
        "蔚来ES8": [1, 6, 15, 19, 8, 21]
    }
}

def print_features():
    """打印可选特征"""
    print("汽车特征列表：\n")
    for i in range(1, len(features)):
        print(f"{i}.{features[i]:<10}", end="")
        if i % 5 == 0: print()
    print()

def get_user_input():
    """获取用户输入并验证"""
    answer = input("请选择汽车的特征编号，用英文逗号分开，回车结束输入：")
    try:
        selected = list(map(int, answer.split(',')))
        # 验证输入是否在有效范围内
        for num in selected:
            if num < 1 or num >= len(features):
                raise ValueError
        return selected
    except Exception:
        print("输入格式错误！请确保：\n1. 只输入有效数字\n2. 使用英文逗号分隔")
        sys.exit()

def classify_car_type(selected):
    """分类汽车类型"""
    features_set = set(selected)
    
    # 判断卡车
    if 13 in features_set or 14 in features_set or 20 in features_set:
        return "卡车"
    
    # 判断跑车
    if (3 in features_set) or (10 in features_set and 11 in features_set):
        return "跑车"
    
    # 判断SUV
    if (6 in features_set and 8 in features_set):
        return "SUV"
    
    # 判断电动车
    if 15 in features_set or 16 in features_set:
        return "电动车"
    
    # 默认轿车
    return "轿车"

def identify_car_brand(car_type, selected):
    """识别具体汽车品牌"""
    selected_set = set(selected)
    max_matches = 0
    best_match = None
    
    for brand, brand_features in brands[car_type].items():
        matches = len(set(brand_features) & selected_set)#取交集
        if matches > max_matches:
            max_matches = matches
            best_match = brand
    
    return best_match if max_matches >= 4 else "未知品牌"

def main():
    print("=== 汽车识别系统 ===")
    print_features()
    selected = get_user_input()
    
    # 显示用户选择的特征
    print("\n您选择的特征：")
    for num in selected:
        print(f"- {features[num]}")
    
    # 分类汽车类型
    car_type = classify_car_type(selected)
    print(f"\n汽车类型: {car_type}")
    
    # 识别具体品牌
    brand = identify_car_brand(car_type, selected)
    print(f"最可能的品牌: {brand}")

if __name__ == "__main__":
    main()