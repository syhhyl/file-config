import sys

FEATURES = {
    1: "有奶",
    2: "有毛发",
    3: "有羽毛",
    4: "会飞",
    5: "会下蛋",
    6: "吃肉",
    7: "有犬齿",
    8: "有爪",
    9: "眼盯前方",
    10: "有蹄",
    11: "嚼反刍",
    12: "黄褐色",
    13: "身上有暗斑点",
    14: "身上有黑色条纹",
    15: "有长脖子",
    16: "有长腿",
    17: "不会飞",
    18: "会游泳",
    19: "有黑白二色",
    20: "善飞",
    21: "哺乳动物",
    22: "鸟",
    23: "食肉动物",
    24: "蹄类动物",
    25: "金钱豹",
    26: "虎",
    27: "长颈鹿",
    28: "斑马",
    29: "鸵鸟",
    30: "企鹅",
    31: "信天翁"
}

# 定义规则库
RULES = [
    {"conditions": [2], "result": 21, "description": "2->21 有毛发→哺乳动物"},
    {"conditions": [1], "result": 21, "description": "1->21 有奶→哺乳动物"},
    {"conditions": [3], "result": 22, "description": "3->22 有羽毛→鸟"},
    {"conditions": [4, 5], "result": 22, "description": "4+5->22 会飞且会下蛋→鸟"},
    {"conditions": [6], "result": 23, "description": "6->23 吃肉→食肉动物"},
    {"conditions": [7, 8, 9], "result": 23, "description": "7+8+9->23 有犬齿、有爪、眼盯前方→食肉动物"},
    {"conditions": [21, 10], "result": 24, "description": "21+10->24 哺乳动物且有蹄→蹄类动物"},
    {"conditions": [21, 11], "result": 24, "description": "21+11->24 哺乳动物且嚼反刍→蹄类动物"},
    {"conditions": [21, 23, 12, 13], "result": 25, "description": "21+23+12+13→25 哺乳动物、食肉、黄褐色、暗斑点→金钱豹"},
    {"conditions": [21, 23, 12, 14], "result": 26, "description": "21+23+12+14→26 哺乳动物、食肉、黄褐色、黑色条纹→虎"},
    {"conditions": [24, 15, 16, 13], "result": 27, "description": "24+15+16+13→27 蹄类、长脖子、长腿、暗斑点→长颈鹿"},
    {"conditions": [24, 14], "result": 28, "description": "24+14→28 蹄类、黑色条纹→斑马"},
    {"conditions": [22, 17, 16, 15, 19], "result": 29, "description": "22+17+16+15+19→29 鸟、不会飞、长脖子、长腿、黑白二色→鸵鸟"},
    {"conditions": [22, 17, 18, 19], "result": 30, "description": "22+17+18+19→30 鸟、不会飞、会游泳、黑白二色→企鹅"},
    {"conditions": [22, 4], "result": 31, "description": "22+4→31 鸟、善飞→信天翁"}
]

def display_features():
    """显示可选特征"""
    print("以下是一些动物的特征：\n")
    for i in range(1, 25):
        print(f"{i}.{FEATURES[i]}", end="  ")
        if i % 4 == 0:
            print()
    print("\n")

def get_user_input():
    """获取用户输入并验证"""
    answer = input("请选择动物的特征编号，用英文逗号分开，回车结束输入：")
    try:
        selected = list(map(int, answer.split(',')))
        print(f"您选择的特征编号: {selected}")
        return selected
    except ValueError:
        print("输入格式错误！请确保输入的是数字并用英文逗号分隔。")
        sys.exit()

def apply_rules(selected_features):
    """应用规则进行推理"""
    # 中间推理过程
    for rule in RULES[:8]:  # 前8条是中间推理规则
        if set(rule["conditions"]).issubset(selected_features):
            print(rule["description"])
            if rule["result"] not in selected_features:
                selected_features.append(rule["result"])
    
    # 最终动物识别
    for rule in RULES[8:]:  # 后7条是最终识别规则
        if set(rule["conditions"]).issubset(selected_features):
            print(f"识别结果: {FEATURES[rule['result']]}")
            return
    
    print("识别失败！无法确定具体动物种类。")

def main():
    """主程序"""
    display_features()
    selected_features = get_user_input()
    apply_rules(selected_features)

if __name__ == "__main__":
    main()