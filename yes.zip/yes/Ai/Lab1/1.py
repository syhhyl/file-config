class RuleTrieNode:
    def __init__(self):
        self.children = {}  # 特征:子节点
        self.conclusion = None  # 到达此节点可能的结论
        self.is_terminal = False  # 是否终结节点

class AnimalExpertSystem:
    def __init__(self):
        # 初始化特征列表
        self.features = [
            "有毛发", "有奶", "有羽毛", "会飞", "会下蛋",
            "有蹄", "反刍", "是食肉动物", "黄褐色", "有暗斑点",
            "有黑色条纹", "有长腿", "有长脖子", "黑白二色", "不会飞",
            "会游泳", "善飞"
        ]
        
        # 初始化规则库
        self.rules = [
            {'conditions': ['有毛发'], 'conclusion': '哺乳动物'},
            {'conditions': ['有奶'], 'conclusion': '哺乳动物'},
            {'conditions': ['有羽毛'], 'conclusion': '鸟'},
            {'conditions': ['会飞', '会下蛋'], 'conclusion': '鸟'},
            {'conditions': ['哺乳动物', '有蹄'], 'conclusion': '有蹄类动物'},
            {'conditions': ['哺乳动物', '反刍'], 'conclusion': '有蹄类动物'},
            {'conditions': ['哺乳动物', '是食肉动物', '黄褐色', '有暗斑点'], 'conclusion': '猎豹'},
            {'conditions': ['哺乳动物', '是食肉动物', '黄褐色', '有黑色条纹'], 'conclusion': '老虎'},
            {'conditions': ['有蹄类动物', '有长腿', '有长脖子', '黄褐色', '有暗斑点'], 'conclusion': '长颈鹿'},
            {'conditions': ['有蹄类动物', '有黑色条纹'], 'conclusion': '斑马'},
            {'conditions': ['鸟', '不会飞', '有长腿', '有长脖子', '黑白二色'], 'conclusion': '鸵鸟'},
            {'conditions': ['鸟', '不会飞', '会游泳', '黑白二色'], 'conclusion': '企鹅'},
            {'conditions': ['鸟', '善飞'], 'conclusion': '信天翁'}
        ]
        
        # 构建Trie树
        self.rule_trie = RuleTrieNode()
        self.build_rule_trie()
        
        # 初始化已知事实
        self.facts = set()
        
    def build_rule_trie(self):
        """构建规则Trie树"""
        for rule in self.rules:
            current = self.rule_trie
            for condition in sorted(rule['conditions']):
                if condition not in current.children:
                    current.children[condition] = RuleTrieNode()
                current = current.children[condition]
            current.conclusion = rule['conclusion']
            current.is_terminal = True

    def insert_rule_trie(self, conditions, conclusion):
        """插入新规则到Trie树"""
        current = self.rule_trie
        for condition in sorted(conditions):
            if condition not in current.children:
                current.children[condition] = RuleTrieNode()
            current = current.children[condition]
        current.conclusion = conditions
        current.is_terminal = True
            
    def clear_screen(self):
        """清屏函数"""
        print("\n" * 50)  # 简单模拟清屏
        
    def print_header(self, title=None):
        """打印标题"""
        self.clear_screen()
        print("=" * 60)
        if title:
            print(" "*((60-len(title))//2) + title)
        else:
            print(" "*15 + "动物识别专家系统（Trie树版）")
        print("=" * 60)
        
    def print_features(self):
        """打印所有可选特征"""
        print("\n可选特征列表:")
        print("-" * 60)
        for i in range(0, len(self.features), 3):
            row = self.features[i:i+3]
            print(" | ".join(f"{i+j+1:>2}. {feature:<15}" for j, feature in enumerate(row)))
        print("-" * 60)
    
    def print_rules(self):
        """打印所有规则"""
        print("\n当前规则库:")
        print("-" * 60)
        for i, rule in enumerate(self.rules, 1):#返回索引和值
            conditions = " ∧ ".join(rule['conditions'])
            print(f"规则{i}: 如果 {conditions} 那么 {rule['conclusion']}")
        print("-" * 60)
        
    def print_current_facts(self):
        """打印当前已选特征"""
        if self.facts:
            print("\n当前已选特征:")
            print("-" * 60)
            print(", ".join(self.facts))
            print("-" * 60)
        else:
            print("\n当前未选择任何特征")
        
    def add_facts_by_numbers(self, numbers_str):
        """通过添加多个事实"""
        try:
            numbers = list(map(int, numbers_str.split())) #分割输入转int再转列表
            added_features = []
            invalid_numbers = []
            
            for num in numbers:
                if 1 <= num <= len(self.features):
                    feature = self.features[num-1]
                    if feature not in self.facts: #不在事实库则添加
                        self.facts.add(feature)
                        added_features.append(feature)
                else:
                    invalid_numbers.append(str(num)) #为什么要再转成str
            
            #调试用
            if added_features:
                print(f"\n✅ 已成功添加特征: {', '.join(added_features)}")
            else:
                print("\n⚠️ 没有添加任何新特征")
            
            if invalid_numbers:
                print(f"⚠️ 忽略无效数字: {', '.join(invalid_numbers)}")
                
        except ValueError:
            print("\n❌ 输入格式错误，请输入用空格分隔的数字")
    
    def add_new_feature(self):
        """添加新特征"""
        self.print_header("添加新特征")
        print("\n当前特征列表:")
        self.print_features()
        
        new_feature = input("\n请输入要添加的新特征名称: ").strip() #移除首尾空格
        if not new_feature:
            print("\n❌ 特征名称不能为空")
            return
            
        if new_feature in self.features:
            print(f"\n⚠️ 特征 '{new_feature}' 已存在")
        else:
            self.features.append(new_feature)
            print(f"\n✅ 已成功添加新特征: {new_feature}")
        
        input("\n按Enter键返回主菜单...")
    
    def add_new_rule(self):
        """添加新规则"""
        self.print_header("添加新规则")
        
        # 显示当前特征和规则
        print("\n当前特征列表:")
        self.print_features()
        print("\n当前规则列表:")
        self.print_rules()
        
        # 输入规则条件
        print("\n请输入规则条件 (输入0结束):")
        conditions = []
        while True:
            self.print_header("添加新规则 - 条件部分")
            print("\n当前已选条件:")
            print(conditions if conditions else "无")
            
            print("\n请选择条件特征:")
            self.print_features()
            print("0. 结束条件输入")
            
            try:
                choice = int(input("\n请输入特征编号: ").strip())
                if choice == 0:
                    break
                elif 1 <= choice <= len(self.features):
                    feature = self.features[choice-1]
                    conditions.append(feature)
                else:
                    print("\n❌ 无效的数字")
            except ValueError:
                print("\n❌ 请输入有效的数字")
            
            input("\n按Enter键继续...")
        
        #调试用
        # if not conditions:
        #     print("\n❌ 规则至少需要一个条件")
        #     input("\n按Enter键返回主菜单...")
        #     return
        
        # 输入规则结论
        self.print_header("添加新规则 - 结论部分")
        print("\n当前已选条件:")
        print(conditions)
        
        conclusion = input("\n请输入规则结论 (动物名称): ").strip()
        if not conclusion:
            print("\n❌ 结论不能为空")
            input("\n按Enter键返回主菜单...")
            return
        
        # 确认并添加规则
        self.print_header("确认新规则")
        print("\n新规则内容:")
        print(f"如果 {' ∧ '.join(conditions)} 那么 {conclusion}")
        
        confirm = input("\n确认添加此规则吗? (y/n): ").strip().lower()
        if confirm == 'y':
            self.rules.append({
                'conditions': conditions,
                'conclusion': conclusion
            })
            # 重建Trie树以包含新规则
            #self.build_rule_trie()
            self.insert_rule_trie(conditions, conclusion)
            print("\n✅ 规则添加成功")
        else:
            print("\n❌ 已取消添加规则")
        
        input("\n按Enter键返回主菜单...")
        
    def infer_with_trie(self):
        """使用Trie树进行推理"""
        if not self.facts:
            print("\n❌ 请先选择至少一个特征")
            return
        
        print("\n推理过程:")
        print("-" * 60)
        
        # 获取已选特征
        selected_features = list(self.facts)
        
        # 在Trie树中搜索匹配的规则
        matched_conclusions = set()
        self._search_trie(self.rule_trie, selected_features, [], matched_conclusions)
        
        # 处理匹配结果
        if matched_conclusions:
            print("\n" + "=" * 30)
            print("🌟 识别结果 🌟")
            print("=" * 30)
            for animal in matched_conclusions:
                print(f"🐾 该动物可能是: {animal}")
                self.facts.add(animal)  # 将结论加入已知事实
            print("=" * 30)
        else:
            print("\n" + "=" * 30)
            print("⚠️ 无法确定具体动物种类")
            print("=" * 30)
            print("当前已知事实:", self.facts)
    
    def _search_trie(self, node, remaining_features, path, results):
        """递归搜索Trie树寻找匹配规则"""
        # 如果当前节点是终止节点，记录结论
        if node.is_terminal:
            results.add(node.conclusion)
        
        # 如果没有剩余特征可匹配，返回
        if not remaining_features:
            return
        
        # 尝试匹配每个剩余特征
        for i, feature in enumerate(remaining_features):
            if feature in node.children:
                # 递归搜索匹配的子节点
                self._search_trie(
                    node.children[feature],
                    remaining_features[:i] + remaining_features[i+1:],
                    path + [feature],
                    results
                )
    
    def reset(self):
        """重置系统"""
        self.facts = set()
        print("\n🔄 系统已重置")
        
    def show_help(self):
        """显示帮助信息"""
        self.print_header("帮助信息")
        print("\n操作指南:")
        print("-" * 60)
        print("1. 基本操作:")
        print("   - 输入特征数字(空格分隔): 添加特征")
        print("   - i/infer: 开始推理")
        print("   - c/clear: 清空当前选择")
        print("   - r/reset: 重置系统")
        print("   - q/quit: 退出程序")
        print("\n2. 扩展功能:")
        print("   - a/add: 添加特征或规则")
        print("   - l/list: 查看所有规则")
        print("   - h/help: 显示帮助信息")
        print("-" * 60)
        input("\n按Enter键返回主菜单...")
        
    def run(self):
        """运行主程序"""
        while True:
            self.print_header()
            self.print_features()
            self.print_current_facts()
            
            print("\n操作指南:")
            print("- 输入特征数字(空格分隔) | a:添加 | l:规则列表")
            print("- i:推理 | c:清空 | r:重置 | h:帮助 | q:退出")
            
            user_input = input("\n请选择操作: ").strip().lower()#移除首尾空格并小写
            
            if user_input == "trie":
                self.print_trie()
            if user_input in ['q', 'quit']:
                print("\n感谢使用动物识别专家系统，再见！")
                break
            elif user_input in ['h', 'help']:
                self.show_help()
            elif user_input in ['r', 'reset']:
                self.reset()
                input("\n按Enter键继续...")
            elif user_input in ['c', 'clear']:
                self.facts = set()
                print("\n🔄 已清空当前选择")
                input("\n按Enter键继续...")
            elif user_input in ['i', 'infer']:
                self.infer_with_trie()
                input("\n按Enter键继续...")
            elif user_input in ['a', 'add']:
                self.print_header("添加功能")
                print("\n1. 添加新特征")
                print("2. 添加新规则")
                print("0. 返回主菜单")
                choice = input("\n请选择操作: ").strip()
                if choice == '1':
                    self.add_new_feature()
                elif choice == '2':
                    self.add_new_rule()
            elif user_input in ['l', 'list']:
                self.print_header("规则列表")
                self.print_rules()
                input("\n按Enter键返回主菜单...")
            else:
                self.add_facts_by_numbers(user_input)
                input("\n按Enter键继续...")


# 运行程序
if __name__ == "__main__":
    expert = AnimalExpertSystem()
    expert.run()