#include <iostream>
#include <string>
#include <algorithm>

class BoyerMoore
{
public:
    int *right;
    std::string pat;

    BoyerMoore(std::string pat) {
        this->pat = pat;

        right = new int[256];
        for (int c = 0; c < 256; c++) right[c] = -1;
        for (int j = 0; j < pat.length(); j++) right[pat[j]] = j;
    }

    int search(std::string txt) {
        int m = pat.length();
        int n = txt.length();
        int skip;
        for (int i = 0; i <= n - m; i += skip) {
            skip = 0;
            for (int j = m-1; j >= 0; j--) {
                if (pat[j] != txt[i+j]) {
                    skip = std::max(1, j - right[txt[i+j]]);
                    break;
                }
            }
            if (!skip) return i;
        }
        return n;
    }
};


int main()
{
    std::string pat, txt;
    std::cout << "pat: txt:";
    std::cin >> pat >> txt;

    BoyerMoore boyermoore = BoyerMoore(pat);
    int offset = boyermoore.search(txt);
    std::cout << "offset:" << offset << std::endl;
    //std::cout << pat << " " << txt;
}