#include <iostream>
#include <stack>
#include <vector>
#include <chrono>


void hanoi(int n, char src, char temp, char tar)
/*
    n:盘中数量
    src：起始柱
    temp: 临时柱
    tar: 目标柱
*/ 
{
    if (n > 0)
    {
        hanoi(n-1, src, tar, temp);
        std::cout << src << "-->" << tar << std::endl;;
        hanoi(n-1, temp, src, tar);
    }
}


void Move(int src, int tar)
{
    std::cout << src << "-->" << tar << std::endl;
}


void hanoi(int n)
{
    if (n <= 0) return;
    if (n == 1) Move(1, 3);

    std::vector<std::stack<int>> tower(3); //初始化tower
    for (int i = n; i > 0; i--) { //初始化A柱
        tower[0].push(i);
    }

    int step = 0; //第几步
    int b = n % 2; //最小盘子移动方向
    int min_curr = 0; //最小盘子所在的柱子

    while (tower[2].size() < n)
    {
        if (step % 2 == 0)
        {

            //奇数 0 2 1 0 2 1
            //偶数 0 1 2 0 1 2
            int next = (min_curr + (b ? 2 : 1)) % 3 ;
            tower[next].push(tower[min_curr].top());
            tower[min_curr].pop();
            Move(min_curr+1, next+1);
            min_curr = next;
        }
        else
        {
            int x = (min_curr + 1) % 3;
            int y = (min_curr + 2) % 3;

            if (tower[x].empty() && tower[y].empty()) break;     
            else if (tower[x].empty())
            {
                tower[x].push(tower[y].top());
                Move(y+1, x+1);
                tower[y].pop();
            }
            else if (tower[y].empty())
            {
                tower[y].push(tower[x].top());
                Move(x+1, y+1);
                tower[x].pop();
            }
            else
            {
                if (tower[x].top() > tower[y].top())
                {
                    tower[x].push(tower[y].top());
                    Move(y+1, x+1);
                    tower[y].pop();
                }
                else
                {
                    tower[y].push(tower[x].top());
                    Move(x+1, y+1);
                    tower[x].pop();
                }
            }
        }
        step++;
    }   
}


void testHanoi(int n)
{
    int64_t t1, t2;

    auto start = std::chrono::high_resolution_clock::now();
    hanoi(n);
    auto end = std::chrono::high_resolution_clock::now();
    t1 = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

    start = std::chrono::high_resolution_clock::now();
    hanoi(n, 'A', 'B', 'C');
    end = std::chrono::high_resolution_clock::now();
    t2 = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();

    std::cout << "hanoi(n):" << t1 << std::endl;
    std::cout << "hanoi(n, src, temp, tar):" << t2 << std::endl;
    


}

int main()
{
    int n;
    std::cin >> n;
    //hanoi(n);
    testHanoi(n);
    //hanoi(n, 'A', 'B', 'C');
}