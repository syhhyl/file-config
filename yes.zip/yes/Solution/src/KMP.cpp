#include <iostream>
#include <string>
#include <vector>

class KMP
{


public:
    int R;
    int m;
    std::string pat;
    std::string txt;
    std::vector<std::vector<int>> dfa;
    std::vector<int> next;

    void getPatAndTxt() {
        std::cout << "pat:";
        std::cin >> pat;
        std::cout << "txt:";
        std::cin >> txt;

        //std::cout << "pat:" << pat << " , txt:" << txt << std::endl;
    }
    KMP() {
        getPatAndTxt();
        
        this->R = 256;
        this->m = pat.length();
    
        dfa = std::vector<std::vector<int>>(R, std::vector<int>(m));
        dfa[pat[0]][0] = 1;
        for (int x = 0, j = 1; j < m; j++) {
            for (int c = 0; c < R; c++) dfa[c][j] = dfa[c][x];
            dfa[pat[j]][j] = j + 1;
            x = dfa[pat[j]][x];
        }
    }

    


    int search() {
        int n = txt.length();
        int i, j;
        for (i = 0, j = 0; i < n && j < m; i++) {
            j = dfa[txt[i]][j];
        }
        if (j == m) return i - m;
        return n;
    }

    int search1() {
        int i, j;
        i = j = 0;
        while (i < txt.length()) {
            if (txt[i] == pat[j]) {
                i++;
                j++;
                if (j == pat.length()) return i - j;
            }
            else {
                if (j > 0) j = next[j-1];
                else i++;
            }
        }

        return -1;
    }


    void showDfa() {
        for (auto row : dfa) {
            for (auto col : row) {
                std::cout << col << " ";
            }
            std::cout << std::endl;
        }  
    }
};



int main(int argc, char *argv[])
{

    KMP kmp1 = KMP();
    int offset1 = kmp1.search();
    int offset2 = kmp1.search1();
    
    std::cout << "search" << std::endl;
    std::cout << "pat:" << kmp1.pat << ", txt:" << kmp1.txt << std::endl;
    std::cout << "start index:" << offset1 << std::endl;

    std::cout << "search1" << std::endl;
    std::cout << "pat:" << kmp1.pat << ", txt:" << kmp1.txt << std::endl;
    std::cout << "start index:" << offset2 << std::endl;

}
