class Digraph:
    def __init__(self, V):
        self.V = V  # 图中顶点的数量
        self.adj = [[] for _ in range(V)]  # 邻接表，表示图的边

    def add_edge(self, v, w):
        """在图中添加一条从 v 到 w 的有向边"""
        self.adj[v].append(w)

    def adjacent(self, v):
        """返回 v 的邻接顶点"""
        return self.adj[v]

class DirectedDFS:
    def __init__(self, graph, sources):
        self.marked = [False] * graph.V
        self.dfs(graph, sources)

    def dfs(self, graph, sources):
        """执行深度优先搜索"""
        stack = list(sources)
        while stack:
            v = stack.pop()
            if not self.marked[v]:
                self.marked[v] = True
                for w in graph.adjacent(v):
                    if not self.marked[w]:
                        stack.append(w)

class NFA:
    def __init__(self, regexp):
        """构造 NFA 对象，根据正则表达式"""
        self.regexp = regexp
        self.m = len(regexp)
        self.graph = Digraph(self.m + 1)
        self.build_nfa()

    def build_nfa(self):
        """构建 NFA"""
        ops = []  # 操作符栈
        for i in range(self.m):
            lp = i
            if self.regexp[i] == '(' or self.regexp[i] == '|':
                ops.append(i)  # 左括号或竖线操作符，入栈
            elif self.regexp[i] == ')':
                or_op = ops.pop()  # 右括号，弹出栈顶
                if self.regexp[or_op] == '|':  # 处理或操作符
                    lp = ops.pop()
                    self.graph.add_edge(lp, or_op + 1)
                    self.graph.add_edge(or_op, i)
                elif self.regexp[or_op] == '(':  # 处理括号
                    lp = or_op
                else:
                    assert False
            if i < self.m - 1 and self.regexp[i + 1] == '*':
                # 闭包操作符
                self.graph.add_edge(lp, i + 1)
                self.graph.add_edge(i + 1, lp)
            if self.regexp[i] == '(' or self.regexp[i] == '*' or self.regexp[i] == ')':
                self.graph.add_edge(i, i + 1)

        if len(ops) != 0:
            raise ValueError("Invalid regular expression")

    def recognizes(self, txt):
        """检测文本是否匹配正则表达式"""
        # 获取起始状态的 epsilon 闭包
        dfs = DirectedDFS(self.graph, [0])
        pc = set(v for v in range(self.graph.V) if dfs.marked[v])

        # 处理文本中的每个字符
        for i in range(len(txt)):
            if txt[i] in ['*', '|', '(', ')']:
                raise ValueError(f"text contains the metacharacter '{txt[i]}'")
            
            match = set()
            # 在状态 pc 中，检查哪些状态能匹配当前字符
            for v in pc:
                if v == self.m:
                    continue
                if self.regexp[v] == txt[i] or self.regexp[v] == '.':
                    match.add(v + 1)
            
            # 如果 match 不为空，计算其 epsilon 闭包
            dfs = DirectedDFS(self.graph, match)
            pc = set(v for v in range(self.graph.V) if dfs.marked[v])

            # 优化：如果没有可达的状态，立即返回 False
            if len(pc) == 0:
                return False

        # 检查是否能到达接受状态
        return self.m in pc

# 测试
if __name__ == "__main__":
    regexp = "a*.b"  # 正则表达式
    txt = ['a', 'ab', 'cb']
    nfa = NFA(regexp)

    for test_str in txt:
        print(f'{test_str} : {nfa.recognizes(test_str)}')

    import re
    print("-----------------------------------")
    for test_str in txt:
        print(f'{test_str} : {True if re.fullmatch(regexp, test_str) else False} ')
