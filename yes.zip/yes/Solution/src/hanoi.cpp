#include <iostream>

void move(char source, char target)
{
    std::cout << source << "-->" << target << std::endl;
}

void hanoi(char source, char aux, char target, int n)
{
    if (n == 1) {
        move(source, target);
        return;
    }

    hanoi(source, target, aux, n-1);
    move(source, target);
    hanoi(aux, source, target, n-1);
}

void insertSort(int* arr, int n)
{
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j+1] = arr[j];
            j--;
        }

        arr[j+1] = key;
    }
}

int main()
{
    //int n;
    //std::cin >> n;
    //hanoi('A', 'B', 'C', n);
    int arr[] = {4, 3, 2, 1};
    insertSort(arr, 4);

    for (auto i : arr) {
        std::cout << i << " ";
    }

    std::cout << "\n";
}