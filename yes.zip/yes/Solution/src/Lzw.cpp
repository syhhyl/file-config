#include <vector>
#include <iostream>
#include <string>
#include <unordered_map>
#include <fstream>


std::vector<int> lzw_compress(const std::string& input)
{
    int dict_size = 256;
    std::unordered_map<std::string, int> dictionary;
    for (int i = 0; i < dict_size; ++i) dictionary[std::string(1, char(i))] = i;


    std::string current = "";
    std::vector<int> compressed;
    for (auto c : input)
    {
        std::string current_plus_c = current + c;
        if (dictionary.find(current_plus_c) != dictionary.end())
        {
            current = current_plus_c;
        }
        else
        {
            compressed.push_back(dictionary[current]);
            dictionary[current_plus_c] = dict_size++;
            current = std::string(1, c);
        }

    }

    if (!current.empty())
    {
        compressed.push_back(dictionary[current]);
    }

    return compressed;
    // for (const auto & pair : dictionary)
    // {
    //     std::cout << pair.first << " : " << pair.second << std::endl;
    // }

    //return std::vector<int>();
}

void lzw_decompress(const std::vector<int>& compressed)
{
    std::ofstream out("compressed.txt");
    int dict_size = 256;
    std::unordered_map<int, std::string> dictionary;
    for (int i = 0; i < dict_size; ++i)
    {
        dictionary[i] = std::string(1, char(i));
    }

    std::string current = std::string(1, char(compressed.front()));
    out << current;


    std::string entry;
    for (size_t i = 1; i < compressed.size(); ++i)
    {
        int code = compressed[i];
        if (dictionary.find(code) != dictionary.end())
        {
            entry = dictionary[code];
        }
        else if (code == dict_size) entry = current + current[0];
        else throw std::invalid_argument("Bad compressed code: " + std::to_string(code));
        out << entry;

        dictionary[dict_size++] = current + entry[0];
        current = entry;
    }

    out.close();
}

int main()
{
    std::string input = "i was your father , but you do not like me";
    std::vector<int> compressed = lzw_compress(input);
    lzw_decompress(compressed);
}