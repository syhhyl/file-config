class NFA:
    #初始化
    def __init__(self, states, alphabet, transitions, start_state, accept_states):
        self.states = states
        self.alphabet = alphabet
        self.transitions = transitions
        self.start_state = start_state
        self.accept_states = accept_states

    #
    def epsilon_closure(self, states):
        #print(type(states))
        #closure = set(states) states就是set,不用转换
        closure = states
        stack = list(states)
        while stack:
            state = stack.pop()
            if (state, '') in self.transitions:
                for next_state in self.transitions[(state, '')]:
                    if next_state not in closure:
                        closure.add(next_state)
                        stack.append(next_state)
        return closure

    def move(self, states, symbol):
        next_states = set()
        for state in states:
            if (state, symbol) in self.transitions:
                next_states.update(self.transitions[(state, symbol)])
        return next_states

    def accepts(self, input_string):
        current_states = self.epsilon_closure({self.start_state})
        for symbol in input_string:
            current_states = self.epsilon_closure(self.move(current_states, symbol))
        return any(state in self.accept_states for state in current_states)

# 定义 NFA
states = {'q0', 'q1', 'q2'}
alphabet = {'a', 'b'}
transitions = {
    ('q0', 'a'): {'q0', 'q1'},
    ('q0', 'b'): {'q0'},
    ('q1', 'b'): {'q2'},
    ('q2', 'a'): {'q2'},
    ('q2', 'b'): {'q2'},
}
start_state = 'q0'
accept_states = {'q2'}

nfa = NFA(states, alphabet, transitions, start_state, accept_states)

# 测试 NFA
test_strings = ['ab', 'aaa', 'aab', 'aba', 'baa', 'bab', 'bbab', 'bbb', 'ba']
for test_string in test_strings:
    print(f"'{test_string}' is accepted: {nfa.accepts(test_string)}")

