from collections import deque

class ACNode:
    def __init__(self):
        self.children = {} #字典
        self.fail = None
        self.output = []

class ACAutomaton:
    def __init__(self):
        self.root = ACNode()

    def insert(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = ACNode()
            node = node.children[char]
        node.output.append(word)

    def build_failure_links(self):
        queue = deque()
        for child in self.root.children.values():
            child.fail = self.root
            queue.append(child)
        
        while queue:
            current_node = queue.popleft()
            for char, child in current_node.children.items():
                fail_node = current_node.fail
                while fail_node and char not in fail_node.children:
                    fail_node = fail_node.fail
                child.fail = fail_node.children[char] if fail_node else self.root
                child.output.extend(child.fail.output)
                queue.append(child)

    def search(self, text):
        node = self.root
        matches = []
        for i, char in enumerate(text):
            while node and char not in node.children:
                node = node.fail
            if not node:
                node = self.root
                continue
            node = node.children[char]
            if node.output:
                matches.extend((i - len(word) + 1, word) for word in node.output)
        return matches

# 示例用法
ac = ACAutomaton()
patterns = ["he", "she", "his", "hers"]
for pattern in patterns:
    ac.insert(pattern)
ac.build_failure_links()
text = "ahishers"
matches = ac.search(text)
print(matches)  # 输出匹配的位置和模式串