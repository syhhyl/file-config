#include <unordered_map>
#include <vector>
#include <string>
#include <queue>
#include <utility>
#include <iostream>

class AcNode
{
public:
    std::unordered_map<char, AcNode*> children;
    AcNode* fail;
    std::vector<std::string> output;
};

class AcAutomaton
{
public:
    AcNode* root;

    AcAutomaton() : root(new AcNode()) {
        root->fail = nullptr;
    }
    
    void insert(const std::string& word) {
        AcNode* node = root;
        for (char c : word) {
            if (node->children.count(c) == 0) {
                node->children[c] = new AcNode();
            }
            node = node->children[c];
        }
        node->output.push_back(word);
    }

    void build_failure_links() {
        std::queue<AcNode*> queue;

        for (auto pair : root->children) {
            pair.second->fail = root;
            queue.push(pair.second);
        }
        
        while (!queue.empty()) {
            AcNode* current_node = queue.front();
            queue.pop();
            for (auto pair : current_node->children) {
                AcNode* fail_node = current_node->fail;

                while (fail_node != nullptr && fail_node->children.count(pair.first) == 0) {
                    fail_node = fail_node->fail;
                }

                pair.second->fail = fail_node != nullptr ? fail_node->children[pair.first] : root;
                pair.second->output.insert(pair.second->output.end(), pair.second->fail->output.begin(), pair.second->fail->output.end());
                queue.push(pair.second);
            }   
        }
    }
    

    std::vector<std::pair<int, std::string>> search(const std::string& text) {
        AcNode* node = root;
        std::vector<std::pair<int, std::string>> matches;

        for (size_t i = 0; i < text.size(); i++) {
            while (node != root && node->children.count(text[i]) == 0) {
                node = node->fail;
            }

            if (node->children.count(text[i]) > 0) {
                node = node->children[text[i]];
            }
              
            if (!node->output.empty()) {
                for (auto word : node->output) {
                    matches.emplace_back(i-word.size()+1, word);
                }
            }
        } 
        return matches;
    }        
};

int main()
{
    auto ac = AcAutomaton();
    std::vector<std::string> patterns = {"he", "she", "hers", "his"};

    for (auto word : patterns) {
        ac.insert(word);
    }

    ac.build_failure_links();


    std::string text;
    std::cin >> text;

    //ac.search(text);
    auto matches = ac.search(text);

    for (auto pair : matches) {
        std::cout << pair.first << ":" << pair.second << std::endl;
    }
}