#include <iostream>
#include <stack>



int main()
{
    std::stack<int> Stack;
    Stack.push(10);
    Stack.push(20);
    std::cout << Stack.top() << "\n";
    Stack.pop();
    std::cout << Stack.top() << "\n";
    if (Stack.empty()) std::cout << "Stack is empty\n";
    else std::cout << "no empty\n";

    Stack.pop();
    if (Stack.empty()) std::cout << "Stack is empty\n";
    else std::cout << "no empty\n";
    
}