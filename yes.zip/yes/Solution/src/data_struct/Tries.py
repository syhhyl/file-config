class TrieNode:
    """
    Trie树节点
    """
    def __init__(self):
        self.children = {}
        self.is_end = False

class Trie:
    """
    Trie树
    """
    def __init__(self):
        self.root = TrieNode()

    def insert(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_end = True
    
    def search(self, prefix):
        """
        查找所有以prefix为前缀的单词
        """

        node = self.root
        for char in prefix:
            if char not in node.children:
                return []
            node = node.children[char]
        return self._find_all_words(node, prefix)

    def _find_all_words(self, node, prefix):
        words = []
        if node.is_end:
            words.append(prefix)
        for char, child_node in node.children.items():
            words.extend(self._find_all_words(child_node, prefix+char))
        return words

if __name__ == "__main__":
    trie = Trie()
    trie.insert("apple")
    trie.insert("app")
    trie.insert("ap")
    trie.insert("a")
    trie.insert("apples")
    trie.insert("applesauce")

    print(trie.search("ba"))

    # a = {'a': 1, 'b': 2, 'c': 3}
    # for char, child_node in a.items():
    #     print(char, child_node)
    
    # w = []
    # w.extend()
