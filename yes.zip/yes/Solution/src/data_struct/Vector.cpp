#include <iostream>
#include <vector>
#include <map>
int main()
{

    //创建vector对象
    std::vector<std::string> vec;
    std::vector<int> vec1(11);
    std::vector<std::map<std::string, int>> vec2(5, {{"sunny", 1}});
    std::vector<std::string> vec3 = {"hello", "world"};
    std::vector<int> vec4 = {1, 2, 3, 4, 5};
    std::vector<int> vec5(vec4);

    for (auto i : vec5) {
        std::cout << i << "\n";
    }

    //添加元素
    vec.push_back("sunny");
    vec1.push_back(100);
    vec2.push_back({{"winder", 2}});
    vec3.push_back("jack");
    vec4.push_back(8);

    //获取大小
    std::cout << vec.size() << "\n";
    std::cout << vec1.size() << "\n";
    std::cout << vec2.size() << "\n";
    std::cout << vec3.size() << "\n";
    std::cout << vec4.size() << "\n";

    //访问元素
    std::cout << vec[0] << "\n";
    std::cout << vec1.at(2) << "\n";

    //迭代访问
    for (auto it = vec2.begin(); it != vec2.end(); ++it) {
        //std::cout << *it  << " ";
        for (auto pair : *it) {
            std::cout << pair.first << ":" << pair.second << "\n";
        }
    }
    std::cout << std::endl;

    for (auto ele : vec3) {
        std::cout << ele << " ";
    }
    std::cout << std::endl;

    for (int i=0; i < vec4.size(); i++) {
        std::cout << vec4[i] << std::endl;
    }

    //删除元素

    vec.erase(vec.begin());//删除第一个元素
    vec1.erase(vec1.begin()+2);//删除第3个元素
    
    //清空元素
    vec.clear();
    vec1.clear();
    vec2.clear();

    std::cout << vec1[0];
}