#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define ERROR 0		                                          
#define OK 1
#define FALSE 0
#define TRUE 1

typedef struct Node
{
	char data;
	struct Node *next;
}Node, *LinkList;

void ListCreat_L(LinkList head)
{	
	char input;
    scanf("%c", &input);
    getchar();
    Node *p = head;
    while (input != '$') {
        Node *newNode = (Node*)malloc(sizeof(Node));
        newNode->next = NULL;
        newNode->data = input;
        p->next = newNode;
        p = newNode;
        scanf("%c", &input);
        getchar();
    }
}

void ListPrint_L(LinkList head)
{
    int i = 1;
    Node *curr = head->next;
    while (curr != NULL) {
        printf("第%d个元素是:%c\n",i,curr->data);
        i++;
        curr = curr->next;
    }
}

void ListInsert_L(LinkList head, int i, char e)
{   
    
    if (i <= 0) {
        printf("插入位置错误！\n");
        return;
    }

    int length = 0;
    Node *p = head->next;
    while (p != NULL) {
        length++;
        p = p->next;
    }

    if (i > length + 1) {
        printf("插入位置不合理！\n");
        return;
    }

    Node *prev = head;
    for (int j = 1; j < i; j++) {
        prev = prev->next;
    }

    Node *newNode = (Node*)malloc(sizeof(Node));
    newNode->data = e;
    newNode->next = prev->next;
    prev->next = newNode;
  
}
int main()
{
    Node *head = (Node*)malloc(sizeof(Node));
    ListCreat_L(head);
    ListPrint_L(head);
    ListInsert_L(head, 1, 'y');
    ListPrint_L(head);
}