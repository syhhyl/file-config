#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define scanf_s scanf
typedef int ElemType; // 元素类型
// 线性列表存储结构
typedef struct LNode
{
    ElemType data;
    struct LNode *next;
}LNode, *LinkList;
int menu_select() // 菜单驱动程序
{
	int sn;
	printf("       链表的逆置\n"); // 显示菜单
	printf("==============================\n");
	printf("   1、链表的建立\n");
	printf("   2、链表的逆置结果\n");
	printf("   0、退出\n");
	printf("==============================\n");
	printf("  请选择0--2:  ");
	for(;;) // 菜单功能选择
	{
		scanf_s("%d",&sn);
		getchar();
		if(sn<0 || sn>2)
			printf("\n\t 输入选择错误，请重新选择 0--2： ");
		else
			break;
	}
	return sn;
}
void ListCreate(LinkList L, int n) // 创建含有n个结点的链表
{
    int i;
    LinkList p, q;
    p = L;
    for(i = 0 ; i < n; i++)
    {
        q = (LNode *)malloc(sizeof(LNode)); // 生成新结点
        scanf("%d", &q->data);
        q->next = NULL;
        p->next = q; // 前后结点链接
        p = q;
    }
}
/* 
TODO: 链表的逆置
功能说明：以链式存储结构实现线性表的就地逆置。
注：线性表的就地逆置就是在原表的存储空间内将线性表（a1,a2,a3,…,an）逆置为（an，an-1，…，a2，a1）
参数说明：L是链表
*/
void ListReverse(LinkList L)
{  
	if (L->next == NULL) return;
    LNode *pre, *cur, *next;
    pre = NULL;
    cur = L->next;
    next = NULL;

    while (cur != NULL) {
        next = cur->next;
        cur->next = pre;
        pre = cur;
        cur = next;
    }
    L->next = pre;
}
void ListShow(LinkList L)
{
    LNode* p = L;
    while(p->next)
    {
        p = p->next;
        printf("%4d", p->data);
    }
    printf("\n");
}
int main()
{
	int n;
    LNode L;
	for(;;) // 无限循环,选择0 退出
	{
		switch(menu_select()) // 调用菜单函数，按返回值选择功能函数
		{
			case 1:
				printf("请输入个数：");
			    scanf("%d", &n);
			    ListCreate(&L, n);
				break;
			case 2:
			    ListReverse(&L);
				printf("逆置的结果是:\n");
				ListShow(&L);
				printf("\n");
				break;
			case 0:
				printf(" 再见！\n"); // 退出系统
				return 0;
		} // switch语句结束
	} // for循环结束

	return 0;
} // main()函数结束
