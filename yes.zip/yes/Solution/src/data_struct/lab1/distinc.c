#include <stdio.h>
#include <malloc.h>
#define scanf_s scanf
#define LIST_INIT_SIZE 100
typedef int ElemType;

typedef struct {
	ElemType *elem; // 存储空间基址
	int length; // 当前长度
} SqList;

int menu_select() // 菜单驱动程序
{
	int sn;
	printf("       在顺序表上删除所有值相等的多余元素\n"); //显示菜单
	printf("==============================\n");
	printf("   1、顺序表的建立\n");
	printf("   2、删除表中值相等的多余元素\n");
	printf("   3、显示顺序表的内容\n");
	printf("   0、退出\n");
	printf("==============================\n");
	printf("  请选择0--3:  ");
	for (;;) // 菜单功能选择
			{
		scanf_s("%d", &sn);
		getchar();
		fflush(stdin);
		if (sn < 0 || sn > 3)
			printf("\n\t 输入选择错误，请重新选择 0--3： ");
		else
			break;
	}
	return sn;
}
void InitList(SqList *l) { // 初始化顺序表
	l->elem = (ElemType*) malloc(LIST_INIT_SIZE * sizeof(ElemType));
	l->length = 0;
}
void CreateList(SqList *l) { // 创建顺序表
	int data, i = 0;
	scanf("%d", &data);
	while (!(data < 0)) {
		l->elem[i++] = data;
		l->length++;
		scanf("%d", &data);
	}
}
void print(SqList list) { // 打印顺序表
	int i = 0;
	while (i < list.length) {
		printf("%d ", list.elem[i++]);
	}
	printf("\n");
}
/* 
TODO: 删除表中值相等的多余元素
参数说明: l是顺序表
注：1 2 2 2 2 2 2 2 2 2 90删除表中值相等的多余元素后为1 2 90
*/
void distinc(SqList *l) { //去除重复元素
	if (l == NULL) return;
	int i = 0;
	for (int j=1; j<l->length; j++) {
		if (l->elem[j] != l->elem[i]) {
			l->elem[++i] = l->elem[j];
		}
	}
	l->length = i+1;
}
void main() {

	// SqList L;
	// L.length = 100;
	// L.elem[0] = 1;
	// L.elem[1] = 2;
	// printf("%d\n", L.length);
	// print(L);
	SqList L;
	InitList(&L);
	for (;;) // 无限循环,选择0 退出
	{
		switch (menu_select()) // 调用菜单函数，按返回值选择功能函数
		{
		case 1:
			printf("建立并输入顺序表:\n");
			printf("输入正整数：（负数代表结束输入）\n");
			CreateList(&L);
			break;
		case 2:
			printf("去除重复元素：");
			distinc(&L);
			break;
		case 3:
			print(L);
			printf("\n");
			break;
		case 0:
			printf(" 再见！\n"); //退出系统
			return;
		} // switch语句结束
	} // for循环结束
} // main()函数结束
