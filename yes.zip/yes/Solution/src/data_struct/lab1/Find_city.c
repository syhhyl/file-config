#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
//常用的宏定义符号常量
#define ERROR 0		                                          
#define OK 1
#define FALSE 0
#define TRUE 1
//请在此填写数据类型说明
typedef struct City_List {
	char name[10];
	float x;
	float y;
	struct City_List *next;
} City_List, *Lhead;
int menu_select()	//菜单驱动程序
{
	int sn;      //sn用于接收菜单选项
	printf("城市管理系统\n");		//显示菜单
	printf("==============================\n");
	printf("1、创建城市链表\n");
	printf("2、根据城市名查询城市\n");
	printf("3、根据中心坐标距离查询城市\n");
	printf("0、退出\n");
	printf("==============================\n");
	printf("请选择0--3:");
	for (;;)		//菜单功能选择
			{
		scanf("%d", &sn);
		getchar();
		if (sn < 0 || sn > 3)          //判断菜单选项是否属于合理范围：0--4
			printf("输入选择错误，请重新选择 0--5:");
		else
			break;
	}
	return sn;
}
/*  
 TODO：添加城市信息
 功能：添加城市信息到链表中，城市信息分为城市名称和城市坐标
 城市名称对应结构体City_List 的name，坐标对应结构体City_List 的x，y
 printf("请输入城市名\n") 输入一个字符串，作为城市名;
 printf("请输入城市坐标\n") 输入两个浮点型f数字，中间用一个字符隔开;
 与Create_List函数联动之后的效果如下：
 输入END推出，输入其余值继续
 1
 请输入城市名
 LA
 请输入城市坐标
 1.00 2.00
 输入END推出，输入其余值继续
 1
 请输入城市名
 BA
 请输入城市坐标
 1.00 3.00
 输入END推出，输入其余值继续
 END
 
 参数：City_List *Lhead 是需要操作的链表
 返回值： 无
 */


void Insert(City_List *Lhead) {
    City_List *newCity = (City_List*)malloc(sizeof(City_List));
	newCity->next = NULL;
    printf("请输入城市名\n");
    scanf("%s", newCity->name);
    printf("请输入城市坐标\n");
    scanf("%f%f", &newCity->x, &newCity->y);
    City_List *cur = Lhead;
	while (cur->next != NULL) {
		cur = cur->next;
	}
	cur->next = newCity;
}


/*  
 TODO：创建链表
 功能：创建链表，添加元素时提示：printf("输入END推出，输入其余值继续\n");
 如果录入END，停止添加；录入其他字符，则调用Insert方法，插入元素
 参数：City_List *Lhead 是需要操作的链表
 返回值： 无
 */
void Create_List(City_List *Lhead) {
    char input[10];
    while (1) {
        printf("输入END退出，输入其余值继续\n");
        scanf("%s", input);
        if (strcmp(input, "END") == 0) break;
		Insert(Lhead);
    }
}
/*  
 TODO：搜索城市信息
 功能：通过城市姓名，搜索城市信息，提示：printf("请输入您要搜索的城市名\n");
 如果如果找到对应的城市信息，则打印城市坐标printf("城市坐标为%.2f,%.2f\n")
 未找到城市信息，提示printf("你要搜索的城市不存在\n");
 比如：
 请输入您要搜索的城市名
 AA
 城市坐标为1.00,2.00
 请输入您要搜索的城市名
 BA
 你要搜索的城市不存在
 
 参数：City_List *Lhead 是需要操作的链表
 返回值： 无
 */
void Find_City(City_List *Lhead) {
    char cityName[10];
    printf("请输入您要搜索的城市名\n");
    scanf("%s", cityName);

    City_List *current = Lhead->next;
    while (current != NULL) {
        if (strcmp(current->name, cityName) == 0) {
            printf("城市坐标为%.2f,%.2f\n", current->x, current->y);
        	return;
        }
        current = current->next;
    }
	printf("你要搜索的城市不存在\n");
}
/*  
 TODO：查询距离范围内城市
 功能：给定一个位置坐标P和一个距离D，返回所有与P的 距离小于等于D的城市。
 printf("请输入中心坐标\n");
 printf("请输入距离\n");
 计算距离判断：((x-Lhead->x)*(x-Lhead->x)+(y-Lhead->y)*(y-Lhead->y)<=distance*distance)
 如果找到符合要求的城市，打印出所有城市信息
 printf("城市名为%s\n");
 printf("城市坐标为%.2f,%.2f\n");
 
 如已有三座城市：LA（1.00,2.00） BA（1.00,3.00） CA（10.00,83.00），市中心（10.00,8.00）
 想查询距离市中心距离12以内的城市：
 请输入中心坐标
 10.00 8.00
 请输入距离
 12
 城市名为LA
 城市坐标为1.00,2.00
 城市名为BA
 城市坐标为1.00,3.00
 参数：City_List *Lhead 是需要操作的链表
 返回值： 无
 */
void Find_City_Distance(City_List *Lhead) {
    float centerX, centerY, distance;
    printf("请输入中心坐标\n");
    scanf("%f%f", &centerX, &centerY);
    printf("请输入距离\n");
    scanf("%f", &distance);

    City_List *current = Lhead->next;
    while (current != NULL) {
        if ((centerX-current->x)*(centerX-current->x)+(centerY-current->y)*(centerY-current->y)<=distance*distance) {
            printf("城市名为%s\n", current->name);
            printf("城市坐标为%.2f,%.2f\n", current->x, current->y);
        }
        current = current->next;
    }
}
int main() {
	//声明一个全局数据变量，并将其初始化
	City_List *Lhead;
	Lhead = (City_List*) malloc(sizeof(City_List));
	Lhead->next = NULL;
	for (;;)						// 菜单驱动程序：无限循环菜单功能选择与调用相应功能函数,直到选择0 退出
			{
		switch (menu_select())	 // 调用菜单函数，按返回值选择功能函数
		{
		case 1:
			printf("创建城市链表\n");
			//功能1的函数调用
			Create_List(Lhead);
			break;
		case 2:
			printf("根据城市名查询城市\n");
			//功能2的函数调用
			Find_City(Lhead);
			break;
		case 3:
			printf("根据中心坐标距离查询城市\n");
			//功能3的函数调用
			Find_City_Distance(Lhead);
			break;
		case 0:
			printf("再见!\n");				//退出系统
			return 0;
		} // switch语句结束 
	} // for循环结束 
    return 0;
} // main()函数结束
