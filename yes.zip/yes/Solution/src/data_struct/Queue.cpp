#include <iostream>
#include <queue>


void showQ(std::queue<int> q)
{
    // int size = q.size();
    // for (int i=0; i<size; i++) {
    //     std::cout << q.front() << "\n";
    //     q.pop();
    // }

    while (!q.empty()) {
        std::cout << q.front() << " ";
        q.pop();
    }

    std::cout << std::endl;
}

int main()
{
    std::queue<int> Queue;
    Queue.push(10);
    Queue.push(20);
    Queue.push(30);
    Queue.push(40);
    Queue.push(50);
    Queue.push(60);
    Queue.push(70);

    
    
    
    //访问头尾元素
    // std::cout << "queue head:" << Queue.front() << "\n";
    // std::cout << "queue back:" << Queue.back() << "\n";
    
    //删除头元素，出队
    //Queue.pop();
    //std::cout << Queue.size() << "\n";
    showQ(Queue);
    
}