#include <map>
#include <iostream>

int main()
{
    std::map<int, std::string> map;
    std::map<int, std::string> map2 = {{1, "one"}, {2, "two"}, {3, "three"}};
    std::cout << map2[2] << std::endl;

    map.insert({6, "six"});
    std::cout << map[1] << "\n"; //map[1]原先没有值，但是map[1]会添加一个默认值
    std::cout << map.at(1) << "\n";//有了默认值，map.at(1)就不会抛出错误

    //删除操作
    //map.erase(6);
    

    //查找操作
    auto it = map.find(6);
    if (it != map.end())
    {
        std::cout << "Found: " << it->first << " " << it->second << std::endl;
        std::cout << "Found: " << (*it).first << " " << (*it).second << std::endl;
        it->second = "eight";
    }

    
    std::cout << map[6] << std::endl;


    for (auto it : map2) {
        std::cout << it.first << " " << it.second << std::endl;
    }

    map2.clear();

    
    

}