#include <iostream>
#include <string>
class Rk
{
public:
    std::string pat;
    long patHash;
    int m;
    long q;
    int R;
    long RM;

    Rk(std::string pat) {
        this->pat = pat; //模式串
        R = 256; //字符集
        m = pat.length(); //模式串的长度
        q = 107; //大素数

        RM = 1;
        for (int i = 1; i <= m-1; i++) RM = (R * RM) % q;
        patHash = hash(pat, m);
    }

    long hash(std::string key, int m) {
        long h = 0;
        for (int j = 0; j < m; j++) {
            h = (R * h + key[j]) % q;
        }

        return h;
    }

    int search(std::string txt) {
        int n = txt.length(); //文本的长度
        if (n < m) return n;
        long txtHash = hash(txt, m);
        
        if (patHash == txtHash) return 0;//0-m-1匹配成功就返回,否则从m开始匹配

        for (int i = m; i < n; i++) {
            txtHash = (txtHash + q - RM*txt[i-m]%q) % q;//消除最左边字符的影响
            txtHash = (txtHash*R + txt[i]) % q;         //添加新字符的影响

            int offset = i - m + 1;
            if (patHash == txtHash) return offset;
        }

        return n;

    }
};

int main()
{
    std::string pat, txt;
    std::cout << "pat:";
    std::cin >> pat;
    std::cout << "txt:";
    std::cin >> txt;
    Rk rk = Rk(pat);
    int offset = rk.search(txt);
    std::cout << "offset:" << offset << std::endl;

    

    return 0;
}