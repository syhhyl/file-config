

class NFA
{
    
};