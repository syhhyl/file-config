/*
找零钱问题
100 99 1 各一百张，找396
动态规划实现
贪心算法实现
*/

#include <iostream>
#include <vector>

int 

int main()
{
    
}