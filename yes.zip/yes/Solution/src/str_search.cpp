#include <iostream>
#include <string>

int search(std::string pat, std::string txt)
{
    int M = pat.length();
    int N = txt.length();
    //std::cout << M << " " << N << std::endl;
    for (int i = 0; i <= N-M; i++) {
        int j;
        for (j = 0; j < M; j++) {
            if (txt[i+j] != pat[j]) break;
        }
        if (j == M) return i;
    }
    return N;
}

int search1(const std::string& pat, const std::string& txt)
{
    int j, M = pat.length();
    int i, N = txt.length();
    for (i = 0, j = 0; i < N && j < M; i++) {//i先加1，再判断条件成立
        if (txt[i] == pat[j]) j++;
        else {
            i -= j;
            j = 0;
        }
    }
    //std::cout << "i:" << i << std::endl;
    if (j == M) return i - M;
    else return N;
}

int main()
{
    std::cout << search1("eh", "hello") << std::endl;
}