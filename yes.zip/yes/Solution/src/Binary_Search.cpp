#include <iostream>
#include <chrono>
#include <functional>
#include <random>
#include <vector>
#include <algorithm>


//二分查找
int Binary_Search(std::vector<int> arr, int n, int tar)
{
    int li, hi, mid;
    li = 0, hi = n-1;

    while (li <= hi) {
        mid = li + (hi-li)/2;
        if (arr[mid] == tar) return mid;
        else if (arr[mid] < tar) li = mid + 1;
        else hi = mid - 1;

    }

    return -1;
}
//线性查找
int Search(std::vector<int> arr, int n, int tar)
{
    for (int i = 0; i < n; i++) {
        if (arr[i] == tar) return i;
    }
    return -1;
}



//函数执行效率
void Duration(std::function<int(std::vector<int> arr, int n, int tar)> func, std::vector<int> arr, int n, int tar)
{
    auto start = std::chrono::high_resolution_clock::now();
    func(arr, n, tar);
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "运行时间:" << elapsed.count() << "ms" << std::endl;
}

void Duration(std::function<bool(std::vector<int>::iterator, std::vector<int>::iterator, int)> func, std::vector<int>::iterator begin, std::vector<int>::iterator end, int tar) {
    auto start = std::chrono::high_resolution_clock::now();
    if (func(begin, end, tar)) std::cout << "find\n";
    auto stop = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
    std::cout << "运行时间:" << elapsed.count() << "ms" << std::endl;
    
}

//生成随机vector
std::vector<int> randomVector(int n)
{   
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(1, 100000);

    std::vector<int> rand_vec;

    for (int i = 0; i < n; ++i) {
        rand_vec.push_back(dis(gen));
    }

    return rand_vec;
} 


int main()
{

    //int arr[] = {1, 3, 5, 7, 9};
    int N;
    std::cout << "数据规模:";
    std::cin >> N;
    std::vector<int> rand_vec = randomVector(N);
    int tar = 100;
    std::cout << "线性查找,";
    //Duration(Search, rand_vec, 5, 5);
    std::cout << "自定义二分查找,";
    //Duration(Binary_Search, rand_vec, 5, tar);
    std::cout << "stl二分查找,";
    Duration(std::binary_search<std::vector<int>::iterator, int>, rand_vec.begin(), rand_vec.end(), tar);
    

    return 0;
    
    // int find_num;
    // std::cin >> find_num;
    // int res_inx = Binary_Search(arr, sizeof(arr)/sizeof(arr[0]), find_num);
    // if (arr[res_inx] == find_num) {
    //     std::cout << "yes\n";
    // }
    // else std::cout << "no\n";

}