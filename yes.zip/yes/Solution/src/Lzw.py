def lzw_compress(uncompressed):
    """Compress a string to a list of output symbols."""
    # Build the dictionary.
    dict_size = 256
    dictionary = {chr(i): i for i in range(dict_size)}
    
    w = ""
    compressed = []
    
    for c in uncompressed:
        wc = w + c
        if wc in dictionary:
            w = wc
        else:
            compressed.append(dictionary[w])
            # Add wc to the dictionary.
            dictionary[wc] = dict_size
            dict_size += 1
            w = c
    
    # Output the code for w.
    if w:
        compressed.append(dictionary[w])
    
    return compressed


def lzw_decompress(compressed):
    """Decompress a list of output symbols to a string."""
    from io import StringIO
    
    # Build the dictionary.
    dict_size = 256
    dictionary = {i: chr(i) for i in range(dict_size)}
    
    # Use StringIO to efficiently build the decompressed string.
    result = StringIO()
    w = chr(compressed.pop(0)) #获取第一个字符
    result.write(w)
    
    for k in compressed:
        if k in dictionary:
            entry = dictionary[k]
        elif k == dict_size:
            entry = w + w[0]
        else:
            raise ValueError('Bad compressed k: %s' % k)
        result.write(entry)
        
        # Add w+entry[0] to the dictionary.
        dictionary[dict_size] = w + entry[0]
        dict_size += 1
        
        w = entry
    
    return result.getvalue()


if __name__ == "__main__":
    original = "The quick brown fox jumps over the lazy dog. "
    compressed = lzw_compress(original)
    decompressed = lzw_decompress(compressed.copy())  # 需要复制一份，因为压缩会修改列表
    
    print(f"原始字符串: {original}")
    print(f"压缩后的编码: {compressed}")
    print(f"解压后的字符串: {decompressed}")
