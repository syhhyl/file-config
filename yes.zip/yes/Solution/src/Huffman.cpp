#include <string>
#include <iostream>
#include <queue>
#include <bitset>
#include <fstream>
#include <memory>
#include <sstream>

class Node
{
public:
    char ch;
    int freq;
    Node* left, * right;

    ~Node() {
        delete left;
        delete right;
    }
    Node(char ch, int freq, Node* left, Node* right) : ch(ch), freq(freq), left(left), right(right) {}

    bool isLeaf() { return (left == nullptr && right == nullptr); }

    int compareTo(Node* that) { return this->freq - that->freq; }
};


struct CompareNodePtr
{
    bool operator ()(const Node* a, const Node* b) const
    {
        return a->freq > b->freq;
    }
};


class Huffman
{
public:
    static int length;
    static std::fstream file;
    static const int R = 256;
    static Node* buildTrie(int* freq);
    static void compress(const std::string& inputFile, const std::string& outputFile);
    static void writeTrie(Node* x, std::ofstream& out);
    static void buildCode(std::string st[], Node* x, const std::string& s);
    static void expand(const std::string& inputFile);
    static Node* readTrie(std::ifstream& in);

};

std::fstream Huffman::file;


void Huffman::compress(const std::string& inputFile, const std::string& outputFile)
{
    std::ifstream in(inputFile, std::ios::binary);
    if (!in.is_open()) 
    {
        std::cerr << inputFile << " open fail\n";
        return;
    }

    std::ofstream out(outputFile, std::ios::binary);
    if (!out.is_open())
    {
        std::cerr << outputFile << " open fail\n";
        return;
    }


    std::stringstream buffer;
    buffer << in.rdbuf();
    std::string s = buffer.str();
    in.close();

    int freq[R] = { 0 };
    int len = s.length();
    for (char c : s) freq[static_cast<unsigned char>(c)]++;

    
    Node* root = buildTrie(freq);//不涉及写入

    std::string st[R];
    buildCode(st, root, ""); //不涉及

    writeTrie(root, out);

    out.write(reinterpret_cast<char*>(&len), sizeof(int));

    for (int i = 0; i < len; i++)
    {  
        std::string code = st[s[i]];
        for (int j = 0; j < code.length(); j++)
        {
            if (code[j] == '0')
            {
                char bit = 0;
                out.write(&bit, sizeof(char));
            }
            else if (code[j] == '1')
            {
                char bit = 1;
                out.write(&bit, sizeof(char));
            }
        }

    }

    out.close();
    delete root;
    std::cout << "压缩完成\n";
}

Node* Huffman::buildTrie(int* freq)
{
    std::priority_queue<Node*, std::vector<Node*>, CompareNodePtr> pq;
    for (int i = 0; i < R; i++)
    {
        if (freq[i] > 0)
        {
            pq.push(new Node(i, freq[i], nullptr, nullptr));
        }
    }

    if (pq.size() == 1)
    {
        if (freq['\0'] == 0) pq.push(new Node('\0', 0, nullptr, nullptr));
        else pq.push(new Node('\1', 0, nullptr, nullptr));
    }

    while (pq.size() > 1)
    {
        Node* left = pq.top();
        pq.pop();
        Node* right = pq.top();
        pq.pop();

        Node* parent = new Node('\0', left->freq + right->freq, left, right);
        pq.push(parent);
    }
    return pq.top();
}

void Huffman::writeTrie(Node* x, std::ofstream& out)
{
    if (x->isLeaf())
    {
        char bit = 1;
        out.write(&bit, sizeof(char));
        out.write(&(x->ch), sizeof(char));
        return;
    }

    char bit = 0;
    out.write(&bit, sizeof(bit));
    writeTrie(x->left, out);
    writeTrie(x->right, out);
}

void Huffman::buildCode(std::string st[], Node* x, const std::string& s)
{
    if (!x->isLeaf())
    {
        buildCode(st, x->left, s + '0');
        buildCode(st, x->right, s + '1');
    }
    
    else st[x->ch] = s;
}


void Huffman::expand(const std::string& inputFile)
{
    std::ifstream in(inputFile, std::ios::binary);
    if (!in.is_open())
    {
        std::cerr << inputFile << " open fail\n";
        return;
    }

    Node* root = readTrie(in);

    int length;//读一个整数
    in.read(reinterpret_cast<char*>(&length), sizeof(int));

    for (size_t i = 0; i < length; i++)
    {
        Node* x = root;
        while (!x->isLeaf())
        {
            char bit;
            in.read(&bit, sizeof(char));
            if (bit) x = x->right;
            else x = x->left;
        }

        std::cout << x->ch;
    }
    
    in.close();
    std::cout << std::endl;
    std::cout << "解压完成\n";
    delete root;

}

Node* Huffman::readTrie(std::ifstream& in)
{
    char isLeaf;
    in.read(&isLeaf, sizeof(char));
    if (isLeaf)
    {   
        char ch;
        in.read(&ch, sizeof(char));
        return new Node(ch, -1, nullptr, nullptr);
    }
    else 
    {
        //显式先构建左树，不然会出错
        Node *left = readTrie(in);
        Node *right = readTrie(in);
        return new Node('\0', -1, left, right);
    }
}

int main()
{
    std::string input, output;
    std::cout << "input file path:";
    std::cin >> input;

    std::cout << "output file path:";
    std::cin >> output;
    //std::cout << file;
    //Huffman::file.open(input, std::ios::binary | std::ios::in);
    Huffman::compress(input, output);
    //Huffman::file.close();
    
    //std::cout << "compress over start expand\n";

    //Huffman::file.open(file, std::ios::binary | std::ios::in);
    int check;
    std::cout << "enter(49 check):";
    std::cin >> check;
    if (check == 49) Huffman::expand(output);
    //Huffman::file.close();

    //std::cout << sizeof(int) << std::endl;

}
