#include <iostream>
#include <map>
#include <unordered_map>

void CountNum(int n)
{
    std::unordered_map<int, int> countMap;

    //初始化为0
    for (int i=0; i<10; i++) {
        countMap[i] = 0;
    }
    // countMap[1] = 100;
    //std::cout << countMap[2] << "\n";
    //处理个位
    for (int i=1; i<=n%10; i++) {
        countMap[i]++;
    }

    int tem = n / 10;
    int count = 1;
    while (tem > 0) {
        for (int i=0; i<10; i++) {
            countMap[i] += tem%10 * count;
        }

        tem /= 10;
        count *= 10;
    }


    //打印结果
    // for (const auto pair : countMap) {
    //     std::cout << pair.first << ":" << pair.second << "\n";
    // }

    

    for (int i=0; i<10; i++) {
        std::cout << i << ":" << countMap[i] << "\n";
    }
}


int main()
{
    int n;
    std::cin >> n;
    CountNum(n);


}