#include <iostream>


bool odd(const int n)
{
    return n % 2 != 0;
}
int main()
{
    int n;
    std::cout << "n:";
    std::cin >> n;
    // while (n>1) {
    //     if (odd(n)) n = 3*n+1;
    //     else n /= 2;
    // }

    for (int i = 1; i <= n; i++) {
        std::cout << "test i:" << i << std::endl;
        while (i > 1) {
            if (odd(i)) i = 3*i+1;
            else i /= 2;
        }
        std::cout << "final i:" << i << std::endl;
    }

    for (int i = 1; i <= n; i++) {
        int temp = i;
        while (temp > 1) {
            if (odd(temp)) temp = 3*temp+1;
            else temp /= 2;
        }
        std::cout << "Number " << i << " converges to " << temp << std::endl;
    }

    //std::cout << "final n:" << n << std::endl;
}