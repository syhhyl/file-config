#include <stdio.h>
#include "LinkedList.h"


LinkedList* CreateLinkedList()
{
    LinkedList* head = (LinkedList*)malloc(sizeof(LinkedList));
    head->data = -1; //头节点设置-1
    head->next = NULL;

    return head;
}

bool empty(LinkedList* ll)
{
    if (ll->next == NULL) return true;
    else return false;
}

int size(LinkedList* ll)
{
    if (ll->next == NULL) return -1;
    int size = 0;
    LinkedList* curr = ll;
    while (curr->next != NULL)
    {
        curr = curr->next;
        size++;   
    }
    return size;
}


ElemType front(LinkedList* ll)
{
    if (ll->next == NULL) return -1;
    return ll->next->data;
}

ElemType back(LinkedList* ll)
{
    if (ll->next == NULL) return -1;
    LinkedList* curr = ll;
    while (curr->next != NULL)
    {
        curr = curr->next;
    }

    return curr->data;
}

void push_front(LinkedList* ll, ElemType data)
{
    if (ll == NULL) return;
    LinkedList* newNode = (LinkedList*)malloc(sizeof(LinkedList));
    newNode->data = data;
    newNode->next = ll->next;
    ll->next = newNode;
}

void push_back(LinkedList* ll, ElemType data)
{
    if (ll == NULL) return;
    LinkedList* newNode = (LinkedList*)malloc(sizeof(LinkedList));
    newNode->data = data;
    LinkedList* curr = ll;
    while (curr->next != NULL)
    {
        curr = curr->next;
    }

    curr->next = newNode;
}

void pop_front(LinkedList* ll)
{
    if (ll->next == NULL) return;
    LinkedList* temp = ll->next;
    ll->next = temp->next;
    free(temp);
}

void pop_back(LinkedList* ll)
{
    if (ll->next == NULL) return;
    LinkedList* curr = ll;
    while (curr->next->next != NULL)
    {
        curr = curr->next;
    }
    free(curr->next);
    curr->next = NULL;
}

void insert(LinkedList* ll, int index, ElemType data)
{
    if (index < 0 || index > size(ll)) return;
    LinkedList* newNode = (LinkedList*)malloc(sizeof(LinkedList));
    newNode->data = data;
    int currIndex = 1;
    LinkedList* curr = ll;
    while (currIndex < index)
    {
        curr = curr->next;
        currIndex++;
    }
    newNode->next = curr->next;
    curr->next = newNode;

}

void erase(LinkedList* ll, int index)
{
    if (index < 0 || index > size(ll)) return;
    LinkedList* curr = ll;
    int currIndex = 1;
    while (currIndex < index)
    {
        curr = curr->next;
        currIndex++;
    }
    LinkedList* temp = curr->next;
    curr->next = temp->next;
    free(temp);
}

void printLinkedList(LinkedList* ll)
{
    if (ll->next == NULL) return;
    LinkedList* curr = ll->next;
    while (curr->next != NULL)
    {
        printf("%d->", curr->data);
        curr = curr->next;
    }
    printf("%d\n", curr->data);
}

int main()
{

    // ElemType d1 = 1;
    // ElemType d2 = 2;
    // ElemType d3 = 3;
    // ElemType d4 = 4;

    LinkedList* head = CreateLinkedList();
    printLinkedList(head);
    if (empty(head)) printf("empty\n");
    push_front(head, 1);
    push_back(head, 2);
    push_back(head, 3);
    printLinkedList(head);
    insert(head, 2, 3);
    printLinkedList(head);
    erase(head, 2);
    printLinkedList(head);
    push_front(head, 10);
    printLinkedList(head);
    push_back(head, 100);
    erase(head, 3);
    printLinkedList(head);
    pop_front(head);
    printLinkedList(head);
    pop_back(head);
    printLinkedList(head);
    

}