#define ElemType int
#include <stdbool.h>
#include <stdlib.h>


typedef struct LinkedList LinkedList;
struct LinkedList
{
    ElemType data;
    LinkedList* next;
};

//创建一个链表
LinkedList* CreateLinkedList();

//是否为空
bool empty(LinkedList* ll);


//返回元素个数
int size(LinkedList* ll);


//返回首元素
ElemType front(LinkedList* ll);


//返回尾元素
ElemType back(LinkedList* ll);


void push_front(LinkedList* ll, ElemType data);


//尾部添加元素
void push_back(LinkedList* ll, ElemType data);


//头部删除元素
void pop_front(LinkedList* ll);

//尾部删除元素
void pop_back(LinkedList* ll);


//插入指定位置元素
void insert(LinkedList* ll, int index, ElemType data);

//删除指定位置元素
void erase(LinkedList* ll, int index);

void printLinkedList(LinkedList* ll);




