#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main()
{
    char* s;
    s = (char*)malloc(10);
    strcpy(s, "cursor");
    printf("cursor is %s\n", s);
    return 0;
}