#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* arr = (int*)malloc(sizeof(int) * 5);

    for (int i = 0; i < 5; i++) {
        //arr[i] = i * 2;
        *(arr+i) = i * 3;
    }

    for (int i = 0; i < 5; i++) {
        //printf("arr[%d] is %d\n", i, arr[i]);
        printf("arr[%d] is %d\n", i, *(arr+i));
    }
}