

int main()
{
    /*
    sum = 1 + 2 + ... + i = (1+i)*i/2

    T(n) = n^(1/2)



     */

    int i = 0, sum = 0;
    int n = 10000000;
    while (sum < n)
    {
        sum += ++i;
    } 

    return 0;
}
