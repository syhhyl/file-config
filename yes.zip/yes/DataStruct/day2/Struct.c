#include <stdio.h>
#include <stdlib.h>


typedef struct
{
    int x;
    int y;
} point;


int main()
{
    point* p = (point*)malloc(sizeof(point));
    p->x = 10;
    p->y = 20;

    printf("p.x %d p.y %d\n", p->x, p->y);

    return 0;    
}
