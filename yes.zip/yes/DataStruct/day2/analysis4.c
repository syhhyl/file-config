

int main()
{
    int sum = 0;
    for (int i = 1; i < n; i*=2)
    {
        for (int j = 0; j < i; j++)
        {
            sum++;
        }
    }
    

    /*
     2^(t-1) = n
     t = log(2)n
     1 + 2 + 4 + ... + 2^(t-1)
     (1-2^t)/(1-2) = (2^t-1)/2 = 2^(t-1) - 1/2
    = 2^(log(2)n) = n 
     *
     * 
     *
     *
     * */
}
