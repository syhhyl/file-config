

int main()
{
    /*
     
     t^2 = n
     t = n^(1/2)

     */

    int x = 0;
    while (n >= (x+1)*(x+1))
    {
        x += 1;
    }
}
