#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* p = (int*)malloc(sizeof(int));
    *p = 20;
    printf("%d\n", *p);
    printf("before &p %p\n", p);
    free(p);//p指向的内存不再被当前程序使用，系统可以回收它，但是p存的地址没变,为了避免悬空，将p设置NULL

    printf("after &p %p\n", p);
    p = NULL;
    return 0;
}