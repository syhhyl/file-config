

int main()
{
    // 2^t+1 = n/2  T(n) = logn
    int x = 2;
    int n = 1000000;
    while (x < n/2)
    {
        x *= 2;
    }

    return 0;
}
