#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define STACK_INIT_SIZE 20
#define STACKINCREMENT 10
#define MAXBUFFER   10
typedef char ElemType;
typedef struct {
	ElemType *base;
	ElemType *top;
	int stackSize;
} sqStack;
void InitStack(sqStack *s) {
	s->base = (ElemType *) malloc(STACK_INIT_SIZE * sizeof(ElemType));
	if (!s->base)
		exit(0);
	s->top = s->base;
	s->stackSize = STACK_INIT_SIZE;
}
/*  
	TODO: 插入元素e为新的栈顶元素
	功能：插入元素e为新的栈顶元素，如果栈满了，则追加存储空间；没满，则将元素插入栈顶，成为新的栈顶元素
	      插入时注意对栈各属性的操作
	参数：SqStack *S是需要操作的栈，ElemType e为插入栈的新元素
	返回值：无。
*/
void Push(sqStack *s, ElemType e) {
    if (s->top - s->base >= s->stackSize) {
        s->base = (ElemType *)realloc(s->base, (s->stackSize + STACKINCREMENT) * sizeof(ElemType));
        if (!s->base)
            exit(0);
        s->top = s->base + s->stackSize;
        s->stackSize += STACKINCREMENT;
    }
    *(s->top) = e;
    s->top++;
}
/*  
	TODO: 弹出栈顶元素
	功能：若栈不空，则删除S的栈顶元素，用e返回其值
	参数：SqStack *S是需要操作的栈，栈顶元素赋值给ElemType *e
	返回值：无。
*/
void Pop(sqStack *s, ElemType *e) {
    if (s->top == s->base)
        return;
    *e = *--(s->top);
}

int StackLen(sqStack s) {
	return (s.top - s.base);
}
/*  
	TODO: 输出中缀表达式对应的后缀表达式
	功能：通过进栈出栈的方式完成中缀表达式对应的后缀表达式的转换，
          从键盘录入中缀表达式，数字与运算符号之间不要有空格（支持“+”“-”“*”“/”“（”“）”即可），    
          录入结束，按“#”完成录入。转换后，输出后缀表达式。数字和运算符号之间用空格隔开，多位数各数位之间不要有空格：
          比如：1+2# 则对应的后缀表达式是1 2 +，输出：1 2 +
          12+23 则对应的后缀表达式输出是12 23 +，不要1 2 2 3 +。
          
          如果录入字母，或者非加减乘除四个运算符，比如 a,b，空格，！，？，%等，则提示：“输入错误!”，返回-1，退出。          
	参数：SqStack *S是需要操作的栈
	返回值：转换成功返回0，失败返回-1 。
*/
int display(sqStack *s) {
    char c;
    char buffer[MAXBUFFER];
    int i = 0;
    int numFlag = 0;
    int firstOutput = 1;  // 标记是否是第一个输出
    
    while ((c = getchar()) != '#') {
        if (isdigit(c)) {
            buffer[i++] = c;
            numFlag = 1;
        } else {
            if (numFlag) {
                buffer[i] = '\0';
                if (!firstOutput) {
                    printf(" ");
                }
                printf("%s", buffer);
                i = 0;
                numFlag = 0;
                firstOutput = 0;
            }
            
            if (c == '(') {
                Push(s, c);
            } else if (c == ')') {
                while (*(s->top - 1) != '(') {
                    char e;
                    Pop(s, &e);
                    if (firstOutput) {
                        printf("%c", e);
                        firstOutput = 0;
                    } else {
                        printf(" %c", e);
                    }
                }
                Pop(s, &c); // 弹出左括号但不输出
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                while (StackLen(*s) > 0 && 
                      ((*(s->top - 1) == '*' || *(s->top - 1) == '/') || 
                       ((*(s->top - 1) == '+' || *(s->top - 1) == '-') && (c == '+' || c == '-')))) {
                    char e;
                    Pop(s, &e);
                    if (firstOutput) {
                        printf("%c", e);
                        firstOutput = 0;
                    } else {
                        printf(" %c", e);
                    }
                }
                Push(s, c);
            } else if (!isspace(c)) {
                printf("输入错误!\n");
                return -1;
            }
        }
    }
    
    if (numFlag) {
        buffer[i] = '\0';
        if (!firstOutput) {
            printf(" ");
        }
        printf("%s", buffer);
        firstOutput = 0;
    }
    
    while (StackLen(*s) > 0) {
        char e;
        Pop(s, &e);
        if (firstOutput) {
            printf("%c", e);
            firstOutput = 0;
        } else {
            printf(" %c", e);
        }
    }
    printf("\n");
    return 0;
}
int main() {
	sqStack s;
	InitStack(&s);
	printf("请输入中缀表达式，以#为结束标志:");
	display(&s);
    return 0;
}
