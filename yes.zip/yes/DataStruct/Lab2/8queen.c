#include <stdlib.h>
#include <stdio.h>
#define true 1
#define false 0
void solve(int row);
int check(int row, int column);
void output();
int m[8][8] = { 0 }; //表示棋盘，初始为0，表示未放置皇后
int num = 0; //解数目
int from;
int to;
int main() {
	printf("  请输入需要打印的解\n");
	printf("  从from开始to结尾\n");
	scanf("%d",&from);
	scanf("%d",&to);
	solve(1);
	return 0;
}
/*TODO:该函数检查在第row行、第column列放置一枚皇后是否可行
 功能描述：在row行以前的行都放置好皇后的前提下，通过判断纵向，斜向确定当前行列是否可以放置皇后
 参数说明：row-整型 代表棋盘的行号
       column-整型 代表棋盘的列号
 返回值说明：true-可以放置
        false-不可以放置
 异常说明：无
 */

int check(int row, int column) {
	int i, j;
	if (row == 0)
		//TODO:第一行随便放 返回true
        return true;
	//TODO：纵向只能有一枚皇后 否则返回false
	for (i = 0; i < row; i++) {
        if (m[i][column])
            return false;
    }
	//TODO：左上至右下只能有一枚皇后 否则返回false
	for (i = row, j = column; i >= 0 && j >= 0; i--, j--) {
        if (m[i][j])
            return false;
    }
	//TODO：右上至左下只能有一枚皇后 否则返回false
	for (i = 0, j = 7; i <= row && j >= column; i++, j--) {
        if (m[i][j])
            return false;
    }
	//TODO：以上以外的时候，检查通过返回true
    return true;
}
/*TODO:该函数通过递归调用来放置八个皇后
 功能描述：该函数求解当棋盘前row行已放置好皇后，在第row+1行继续放置皇后
 参数说明：row-整型 代表棋盘的行号
 返回值说明：无
 异常说明：无
 */
void solve(int row) {
	int j;
	//考虑在第row行的各列放置皇后
	for (j = 0; j < 8; j++) {
		//TODO：在其中一列放置皇后 注意数组是从0开始计算，第row行，在数组是row-1，数组的j列，对于check函数是j+1
		if (check(row-1, j)) {
			//若该列可放置皇后，且该列为最后一列，则找到一可行解，输出
            m[row-1][j] = 1; //放置皇后
			if (row == 8)
				//TODO:调用输出函数output();
                output();
			//若该列可放置皇后，则向下一行，继续搜索、求解
			else
				//TODO：递归查找下一行
                solve(row + 1);
		}
		//TODO:如果放置不可行，取出该列的皇后，进行回溯即设置为0，继续for循环在其他列放置皇后       
        m[row-1][j] = 0;
    }
}
/*
 功能描述：根据用户输入from和to的值，来输出92个答案中从第from个到第to个答案
 */
void output() {
	int i, j;
	num++;
	if(num>=from && num<=to){
		printf("answer %d:\n", num);
		for (i = 0; i < 8; i++) {
			for (j = 0; j < 8; j++)
				printf("%d ", m[i][j]);
			printf("\n");
		}
	}
}



#include <stdlib.h>
#include <stdio.h>
#define true 1
#define false 0
void solve(int row);
int check(int row, int column);
void output();
int m[8][8] = { 0 }; //表示棋盘，初始为0，表示未放置皇后
int num = 0; //解数目
int from;
int to;
int main() {
	printf("  请输入需要打印的解\n");
	printf("  从from开始to结尾\n");
	scanf("%d",&from);
	scanf("%d",&to);
	solve(1);
	return 0;
}
/*TODO:该函数检查在第row行、第column列放置一枚皇后是否可行
 功能描述：在row行以前的行都放置好皇后的前提下，通过判断纵向，斜向确定当前行列是否可以放置皇后
 参数说明：row-整型 代表棋盘的行号
       column-整型 代表棋盘的列号
 返回值说明：true-可以放置
        false-不可以放置
 异常说明：无
 */
int check(int row, int column) {
	int i, j;
	if (row == 0)
		//TODO:第一行随便放 返回true
        return true;
	//TODO：纵向只能有一枚皇后 否则返回false
	for (i = 0; i < row; i++) {
        if (m[i][column])
            return false;
    }
	//TODO：左上至右下只能有一枚皇后 否则返回false
	for (i = row, j = column; i >= 0 && j >= 0; i--, j--) {
        if (m[i][j])
            return false;
    }
	//TODO：右上至左下只能有一枚皇后 否则返回false
	for (i = 0, j = 7; i <= row && j >= column; i++, j--) {
        if (m[i][j])
            return false;
    }
	//TODO：以上以外的时候，检查通过返回true
    return true;
}
/*TODO:该函数通过递归调用来放置八个皇后
 功能描述：该函数求解当棋盘前row行已放置好皇后，在第row+1行继续放置皇后
 参数说明：row-整型 代表棋盘的行号
 返回值说明：无
 异常说明：无
 */
void solve(int row) {
	int j;
	//考虑在第row行的各列放置皇后
	for (j = 0; j < 8; j++) {
		//TODO：在其中一列放置皇后 注意数组是从0开始计算，第row行，在数组是row-1，数组的j列，对于check函数是j+1
		if (check(row-1, j)) {
			//若该列可放置皇后，且该列为最后一列，则找到一可行解，输出
            m[row-1][j] = 1;
			if (row == 8)
				//TODO:调用输出函数output();
                output();
			//若该列可放置皇后，则向下一行，继续搜索、求解
			else
				//TODO：递归查找下一行
                solve(row+1);
		}
		//TODO:如果放置不可行，取出该列的皇后，进行回溯即设置为0，继续for循环在其他列放置皇后       
        m[row-1][j] = 0;
    }
}



/*
 功能描述：根据用户输入from和to的值，来输出92个答案中从第from个到第to个答案
 */
void output() {
	int i, j;
	num++;
	if(num>=from && num<=to){
		printf("answer %d:\n", num);
		for (i = 0; i < 8; i++) {
			for (j = 0; j < 8; j++)
				printf("%d ", m[i][j]);
			printf("\n");
		}
	}
}

