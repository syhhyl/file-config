#include "DoublyLinkedList.h"
#include <stdlib.h>
#include <stdio.h>


DoublyLinkedList* CreateDoublyLinkedList()
{
    DoublyLinkedList* head = (DoublyLinkedList*)malloc(sizeof(DoublyLinkedList));
    head->data = -1; //头节点设置-1
    head->next = NULL;
    head->prev = NULL; //头节点的前驱指针设置为NULL
    return head;
}

void insert_at_head(DoublyLinkedList* head, ElemType data)
{
    DoublyLinkedList* new_node = (DoublyLinkedList*)malloc(sizeof(DoublyLinkedList));
    new_node->data = data;
    new_node->next = head->next;
    new_node->prev = head;

    if (head->next != NULL) head->next->prev = new_node;
    head->next = new_node;
}

void insert_at_tail(DoublyLinkedList* head, ElemType data)
{
    DoublyLinkedList* new_node = (DoublyLinkedList*)malloc(sizeof(DoublyLinkedList));
    new_node->data = data;
    new_node->next = NULL;

    DoublyLinkedList* curr = head;
    while (curr->next != NULL) curr = curr->next;
    curr->next = new_node;
    new_node->prev = curr;
}


void insert_after_node(DoublyLinkedList* node, ElemType data)
{
    if (node == NULL) return;

    DoublyLinkedList* new_node = (DoublyLinkedList*)malloc(sizeof(DoublyLinkedList));
    new_node->data = data;
    new_node->next = node->next;
    new_node->prev = node;

    if (node->next != NULL) node->next->prev = new_node;
    node->next = new_node;
}

void delete_head(DoublyLinkedList* head)
{
    if (head->next == NULL) return;

    DoublyLinkedList* temp = head->next;
    head->next = temp->next;
    if (temp->next != NULL) temp->next->prev = head;

    free(temp);
}

void delete_tail(DoublyLinkedList* head)
{
    if (head->next == NULL) return;

    DoublyLinkedList* curr = head;
    while (curr->next != NULL) curr = curr->next;
    curr->prev->next = NULL;

    free(curr);
}

void delete_node(DoublyLinkedList* head, ElemType data)
{
    if (head->next == NULL) return;

    DoublyLinkedList* curr = head->next;
    while (curr != NULL && curr->data != data) curr = curr->next;

    if (curr == NULL) return;
    if (curr->prev != NULL) curr->prev->next = curr->next;
    if (curr->next != NULL) curr->next->prev = curr->prev;

    free(curr);
}

void search_node(DoublyLinkedList* head, ElemType data)
{
    if (head->next == NULL) return;

    DoublyLinkedList* curr = head->next;
    while (curr != NULL && curr->data != data) curr = curr->next;
    if (curr != NULL)
    {
        printf("data:%d, prev:%d, next:%d\n", data, curr->prev->data, curr->next->data);
        //printf("data:%d\n", data);
    }
    else printf("not found.\n");
}

void print_list(DoublyLinkedList* head)
{
    if (head->next == NULL) return;

    DoublyLinkedList* curr = head->next;

    while (curr->next != NULL)
    {
        printf("%d->", curr->data);
        curr = curr->next;
    }
    //printf("\n");
    printf("%d\n", curr->data);
}


int main()
{
    DoublyLinkedList* head = CreateDoublyLinkedList();
    insert_at_head(head, 1);
    insert_at_head(head, 2);
    print_list(head);
    insert_at_tail(head, 4);
    insert_at_tail(head, 5);
    print_list(head);
    insert_after_node(head->next->next, 6);
    print_list(head);
    delete_head(head->next);
    print_list(head);
    search_node(head, 4);
    search_node(head, 7);

    return 0;
}

