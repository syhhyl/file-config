#define ElemType int


typedef struct DoublyLinkedList DoublyLinkedList;
struct DoublyLinkedList
{
    ElemType data;
    DoublyLinkedList* next;
    DoublyLinkedList* prev;
};


DoublyLinkedList* CreateDoublyLinkedList();

void insert_at_head(DoublyLinkedList* head, ElemType data);
void insert_at_tail(DoublyLinkedList* head, ElemType data);
void insert_after_node(DoublyLinkedList* node, ElemType data);
void delete_head(DoublyLinkedList* head);
void delete_tail(DoublyLinkedList* head);
void delete_node(DoublyLinkedList* node, ElemType data);
void search_node(DoublyLinkedList* head, ElemType data);
void print_list(DoublyLinkedList* head);




