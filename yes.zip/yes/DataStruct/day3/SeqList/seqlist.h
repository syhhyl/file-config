#define ElemType int


typedef struct
{
    ElemType* Data;
    int Size;
    int Capacity;
} seqlist;

//创建顺序表
seqlist* CreateList(int initCapacity);

//扩展
void expand(seqlist* sl);

//删除顺序表
void destroryList(seqlist* sl);

//插入元素
void insert(seqlist* sl, ElemType elem, int index);

//尾部添加元素
void push_back(seqlist* sl, ElemType elem);

//删除元素
int removeElem(seqlist* sl, int index);

//获得元素
int get(seqlist* sl, int index);

//设置元素
void set(seqlist* sl, int index, ElemType elem);

//查找元素
int find(seqlist* sl, ElemType elem);

//打印顺序表
void printList(seqlist* sl);
