#include <stdio.h>
#include <stdlib.h>
#include "seqlist.h"

seqlist* CreateList(int initCapacity)
{
    seqlist* sl = (seqlist*)malloc(sizeof(seqlist));
    sl->Data = (ElemType*)malloc(sizeof(ElemType) * initCapacity);
    sl->Size = 0;
    sl->Capacity = initCapacity;
    return sl;
}

void expand(seqlist* sl)
{
    sl->Capacity *= 2;
    ElemType* newData = (ElemType*)malloc(sizeof(ElemType) * sl->Capacity);
    //拷贝数据
    for (int i = 0; i < sl->Size; i++)
    {
        newData[i] = sl->Data[i];
    }

    sl->Data = newData;
}

void destroyList(seqlist* sl)
{
    free(sl->Data);
    free(sl);
}

void insert(seqlist* sl, ElemType elem, int index)
{
    for (int i = sl->Size-1; i >= index; i--)
    {
        sl->Data[i+1] = sl->Data[i];
    }
    sl->Data[index] = elem;
    sl->Size++;
}

void push_back(seqlist* sl, ElemType elem)
{
    sl->Data[sl->Size] = elem; 
    sl->Size++;
}


int removeElem(seqlist* sl, int index)
{
    ElemType temp = sl->Data[index];
    for (int i = index; i < sl->Size; i++)
    {
        sl->Data[i] = sl->Data[i+1];
    }

    return temp;
}

int get(seqlist* sl, int index)
{
    return sl->Data[index]; 
}

void set(seqlist* sl, int index, ElemType elem)
{
    sl->Data[index] = elem;
}

int find(seqlist* sl, ElemType elem)
{
    for (int i = 0; i < sl->Size; i++)
    {
        if (sl->Data[i] == elem) return i;
    }
}

void printList(seqlist* sl)
{
    for (int i = 0; i < sl->Size; i++)
    {
        printf("%d ", sl->Data[i]);
    }
    printf("\n");
}
int main()
{
        // 创建线性表
    seqlist* list = CreateList(1);
    
    // 添加元素
    push_back(list, 1);
    push_back(list, 2);
    push_back(list, 3);
    
    printList(list);
    // 在指定位置插入元素
    insert(list, 4, 1);
    
    // 打印线性表
    printList(list);  // 输出: [1, 4, 2, 3]
    
    // 删除元素
    //int removed = removeElem(list, 2);
    //printf("Removed: %d\n", removed);
    
    // 修改元素
    //set(list, 1, 5);
    
    // 获取元素
    //printf("Element at index 1: %d\n", get(list, 1));
    
    //printList(list);
    // 查找元素
    //int index = find(list, 3);
    //printf("Index of 3: %d\n", index);
    
    // 销毁线性表
    destroyList(list);
}