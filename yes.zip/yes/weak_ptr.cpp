#include <iostream>
#include <memory>

class B;

class A
{
public:
    std::shared_ptr<B> ptrB;

    A() { std::cout << "A created\n"; }
    ~A() { std::cout << "A destroyed\n"; }
};

class B
{
public:
    std::weak_ptr<A> ptrA;

    B() { std::cout << "B created\n"; }
    ~B() { std::cout << "B destroyed\n"; }
};

int main()
{
    std::shared_ptr<A> a = std::make_shared<A>();
    std::shared_ptr<B> b = std::make_shared<B>();

    a->ptrB = b;
    b->ptrA = a;

    std::cout << "Use count of A: " << a.use_count() << "\n";
    std::cout << "Use count of B: " << b.use_count() << "\n";
    std::cout << "test vim in vscode" << std::endl;
    return 0;
}